/*  TODO
    1) Save by streamer id, with the users to ping inside
    2) Check the streamers every 5 min or so
*/