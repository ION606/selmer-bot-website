module.exports = {
    name: "test",
    description: "HI SELMER",
    execute(interaction, Discord, Client, bot) {
        interaction.reply("HI SELMER!!!");
    },
    options: []
}