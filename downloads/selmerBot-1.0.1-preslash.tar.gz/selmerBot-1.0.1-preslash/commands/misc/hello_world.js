module.exports = {
    name: "test",
    description: "HI SELMER",
    execute(message, args, Discord, Client, bot) {
        message.channel.send("HI SELMER!!!");
    }
}