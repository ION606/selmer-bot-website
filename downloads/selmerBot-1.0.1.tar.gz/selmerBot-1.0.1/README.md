# selmerBot

Authors: ION606, MajorDrools

### Node Packages Installation Instructions
Download the _package.json_ file from the repo
`npm install`


### Run Selmer Bot Locally
Set the entry point to `main.js`, then run using `node .`
